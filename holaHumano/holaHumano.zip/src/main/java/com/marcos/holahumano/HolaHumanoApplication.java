package com.marcos.holahumano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaHumanoApplication {

    public static void main(String[] args) {
        SpringApplication.run(HolaHumanoApplication.class, args);
    }

}
