package com.marcos.holahumano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaHumanoApplicationTests {

    @Test
    void contextLoads() {
    }

}
